## Mellowed
A 16x Minecraft Resource Pack by Kchem and Garden Gals  
https://modrinth.com/project/mellowed 
https://discord.gg/qxRVkGDjdJ